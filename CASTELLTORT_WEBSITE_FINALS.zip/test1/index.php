

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="webstyle.css" />
  </head>
  <body>
    <nav class="navbar">
      <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#About">About</a></li>
        <li><a href="#hobbies">Hobbies</a></li>
        <li><a href="#skills">Skills</a></li>
        <li><a href="#contactinfo">Contact Info</a></li>
        
        <li><a href="login.php"><button class="logout_btn">Log Out</button></a></li>
      </ul>
    </nav>

    <section id="home">
      <div class="main">
        <h1 class="headings">IZACH CASTELLTORT</h1>
        <button class="btn"><a href="#About">Let's Get Started</a></button>
        <button class="btn1"><a href="resume.pdf">Click my Resume</a></button>
      </div>
    </section>

    <section id="About">
      <h1 class="headings">ABOUT ME</h1>
      <div id="pic">
        <img src="akotoh2.jpg" alt="" />
        <div id="intro">
          <h2>HI! I'M ZACH!</h2>
          <p>
            
Greetings, my dear friend! Allow me to introduce myself. I go by the name Sevaztiene Izach Logmao-Castelltort. Yes, I know, it's quite a mouthful, isn't it? But for the sake of simplicity and your convenience, feel free to call me Zach. Currently, I am immersed in my studies as a student pursuing a Bachelor of Science in Information Technology with a major in Mobile and Internet Technology at National University Fairview. I tend to be quite introverted by nature, yet in the presence of those with whom I feel comfortable, my extroverted side emerges. As you navigate through this website and access my personal resume for download, you'll uncover more layers of my personality. Don't hesitate and start scrolling now to get a deeper insight into who I am!


  
          </p>
        </div>
      </div>
    </section>

    <section id="hobbies">
      <h1 class="headings">HOBBIES</h1>
      <div class="gallery">
        <img src="lol.jpg" alt="" />
        <img src="newjeans.jpeg" alt="" />
        <img src="go.jpg" alt="" />
        <img src="2521.jpg" alt="" />
        <img src="singing.jpg" alt="" />
      </div>
    </section>

    <section id="skills">
      <h1 class="headings">SKILLS</h1>
      <div class="row">
        <div class="box">
          <h1 class="headings">In-Game Leadership</h1>
          <p>
As someone who enjoys gaming, I view my in-game leadership abilities as a valuable skill. It took me some time to recognize this, but I am confident that I can positively influence my teammates, boosting their morale and fostering a competitive spirit as we engage in gaming specifically in League of Legends
          </p>
        </div>
        <div class="box">
          <h1 class="headings">Singing</h1>
          <p>
            
Since my time in Primary School, specifically in 2nd Grade, I unearthed a talent and remarkable skill for singing. I actively participated in singing competitions, particularly at my previous school, and fortunately, secured numerous wins along with a few runner-up positions. This discovery has become a defining aspect of my identity, and those who have heard my voice and witnessed my stage performances now refer to me as "The singing Maestro."
          </p>
        </div>
        <div class="box">
          <h1 class="headings">Good Listener</h1>
          <p>
            Many of my friends have remarked on my adept listening skills, and initially, I was taken aback as I hadn't perceived myself in that light. Their stories captivate me, making me wonder if my own life is somewhat uneventful compared to their amusing anecdotes. Nevertheless, as a friend, I am committed to always lending an ear because I firmly believe that listening provides comfort and demonstrates a genuine appreciation for someone's perspective, regardless of the circumstances.
          </p>
        </div>
      </div>
    </section>

    <section id="contactinfo">
        <p class="section_text_p1"></p>
        <h1 class="title">Contact Me</h1>
        <div class="contact-info-upper-container">
            <div class="contact-info-upper-container">
                <img src="email.png" alt="linkedin icon" class="icon contact-icon"
                />
                <p><a href="Emailto:castelltortizach17@gmail.com">castelltortizach17@gmail.com</a></p>
            </div>
            <div class="contact-info-upper-container">
                <img src="linkedin.png" alt="email icon" class="icon contact-icon"
                />
                <p><a href="https://www.linkedin.com/in/sevaztiene-izach-castelltort-5352b9252/">LinkedIn</a></p>
            </div>

        </form>
    </section>
  </body>
</html>
