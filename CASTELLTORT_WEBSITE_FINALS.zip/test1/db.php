<?php

$host = 'localhost'; // or the relevant server address
$username = 'root';
$password = ''; // Password should go here
$database = 'usersform';

$conn = new mysqli('localhost','root','','usersform');
if(!$conn){
    echo "Connection Denied" . mysqli_connect_error();
}


?>