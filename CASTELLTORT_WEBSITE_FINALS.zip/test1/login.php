<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register</title>
    <link rel="stylesheet" href="form.css" />
  </head>
  <body>
    <div class="form">
      <h2>Login Form</h2>
      <form action="">
        <div class="error-text">Error</div>
        <div class="input">
          <label>Email</label>
          <input
            type="email"
            name="email"
            placeholder="Enter Your Email"
            required
          />
        </div>
        <div class="input">
          <label>Password</label>
          <input type="password" name="pass" placeholder="Password" required />
        </div>

        <div class="submit">
       <a href="index.php" class="button"">
    <input type="button" value="Signup Now" class="button" />
  </a>
</div>

      </form>
      <div class="link">Not Yet Registered?<a href="register.php"> Register Now! </a></div>
    </div>
  </body>
</html>
